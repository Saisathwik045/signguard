SignGuard: synthetic-only Streamlit online demonstration

This package reuses the existing synthetic_demo.py and demo.py without edits.
It contains five verified public synthetic PDFs and precomputed JSON/PDF/image evidence.
No arbitrary upload widget, PDF parser, worker, broker, credentials or live analysis is included.
The original repository, forensic algorithms and historical evidence are unchanged.

Deployment proposal (not executed): Streamlit Community Cloud, free plan, private audience.
1. After owner approval, publish this directory as a dedicated PRIVATE GitHub repository. Do not deploy from the public SignGuard repository; public repositories produce public apps by default.
2. Sign into https://share.streamlit.io with your authorized account.
3. Confirm your account has an available private-app slot, then Create app: select the private repository, branch and synthetic_demo.py entrypoint.
4. Advanced settings: Python 3.12. No secrets or paid services are required by this package.
5. Ensure viewing access is private/owner-only before sharing the URL; explicitly invite only approved viewers.
6. Verify five selections, evidence images, and JSON/PDF downloads at the actual hosted origin.
7. Do not use main app.py as the entrypoint, add upload widgets, install forensic dependencies,
   bind any analysis backend, or choose a paid upgrade. Stop if any charge is required.

Community Cloud can sleep inactive apps; this is not a guarantee of always-on service.
Platform runtime, account availability, access controls and hosted package security still require verification.
There is no live deployment or reserved URL yet. Nothing was committed or pushed.
